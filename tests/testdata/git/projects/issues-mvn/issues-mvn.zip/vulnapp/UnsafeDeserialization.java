package com.example.vulnapp;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 * Unsafe Java deserialization for first-party SAST scanning tests.
 */
public final class UnsafeDeserialization {

    private UnsafeDeserialization() {
    }

    public static Object deserializeUntrusted(byte[] payload) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(payload))) {
            return in.readObject();
        }
    }
}
