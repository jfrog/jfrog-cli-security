package com.example.vulnapp;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Intentionally unsafe helpers for first-party SAST scanning tests.
 */
public final class UnsafeOperations {

    private UnsafeOperations() {
    }

    /** OS command injection: user-controlled input passed to a shell. */
    public static Process runUserCommand(String userInput) throws IOException {
        return Runtime.getRuntime().exec(new String[] {"sh", "-c", "echo " + userInput});
    }

    /** Path traversal: arbitrary filesystem read from user-supplied path. */
    public static byte[] readUserFile(String userPath) throws IOException {
        return Files.readAllBytes(Path.of(userPath));
    }

    /** SSRF: fetches a URL supplied by the caller without validation. */
    public static InputStream fetchUserUrl(String userUrl) throws IOException {
        return new URL(userUrl).openStream();
    }
}
