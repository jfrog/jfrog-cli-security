package com.example.vulnapp;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Minimal entry point for Xray binary/JAR scanning tests.
 */
public class App {

    private static final Logger log = LogManager.getLogger(App.class);

    public static void main(String[] args) throws Exception {
        log.info("VulnApp started");
        System.out.println(new GreetingService().greet("scanner"));

        if (args.length > 0) {
            String mode = args[0];
            String input = args.length > 1 ? args[1] : "";
            switch (mode) {
                case "cmd":
                    UnsafeOperations.runUserCommand(input);
                    break;
                case "file":
                    System.out.println(new String(UnsafeOperations.readUserFile(input)));
                    break;
                case "url":
                    System.out.println(UnsafeOperations.fetchUserUrl(input).read());
                    break;
                case "sql":
                    System.out.println(SqlHelper.buildUserLookupQuery(input));
                    break;
                case "hash":
                    System.out.println(InsecureCrypto.hashPasswordMd5(input).length);
                    break;
                case "deserialize":
                    System.out.println(UnsafeDeserialization.deserializeUntrusted(input.getBytes()));
                    break;
                case "secret":
                    System.out.println(HardcodedSecrets.connectString());
                    break;
                default:
                    System.err.println("Unknown mode: " + mode);
            }
        }
    }
}
