package com.example.vulnapp;

/**
 * Hardcoded credentials in source for secret-detection / SAST tests.
 */
public final class HardcodedSecrets {

    // Intentionally embedded for scanning — not real credentials.
    public static final String API_KEY = "sk-live-intentional-test-key-7f3a9b2c1d0e";
    public static final String DB_PASSWORD = "P@ssw0rd!hardcoded-in-source";

    private HardcodedSecrets() {
    }

    public static String connectString() {
        return "jdbc:postgresql://db.example.com:5432/app?user=admin&password=" + DB_PASSWORD;
    }
}
