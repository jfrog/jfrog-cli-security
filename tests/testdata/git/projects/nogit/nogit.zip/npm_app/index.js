console.log('Hello World!'); 

protobuf = require("protobufjs");
protobuf.load("/path/to/untrusted.proto", function(err, root) { return });