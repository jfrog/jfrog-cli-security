# VulnApp Sample

Minimal Maven application for JFrog Xray security scanning end-to-end tests. This repository intentionally contains vulnerable third-party dependencies, first-party code patterns, exposed secrets, and IaC misconfigurations.

## Build

```bash
mvn clean package
```

The JAR is produced at `target/vulnapp-1.0.0.jar`.

Optional CLI demos exercise first-party code paths (not required for static scans):

```bash
java -jar target/vulnapp-1.0.0.jar sql "' OR '1'='1"
java -jar target/vulnapp-1.0.0.jar cmd "test; id"
java -jar target/vulnapp-1.0.0.jar file /etc/passwd
java -jar target/vulnapp-1.0.0.jar url http://169.254.169.254/
java -jar target/vulnapp-1.0.0.jar hash secret
java -jar target/vulnapp-1.0.0.jar secret
```

## Expected findings

### Third-party (SCA) — `pom.xml`

| CVE | Severity | Component | Notes |
|-----|----------|-----------|-------|
| CVE-2021-44228 | Critical | `log4j-core` 2.14.1 | Log4Shell |
| CVE-2017-7525 | High | `jackson-databind` 2.9.8 | Polymorphic deserialization |
| CVE-2018-14718 | High | `jackson-databind` 2.9.8 | Polymorphic deserialization |
| CVE-2019-12384 | High | `jackson-databind` 2.9.8 | Polymorphic deserialization |
| CVE-2015-6420 | High | `commons-collections` 3.2.1 | Unsafe deserialization gadget chain |
| CVE-2022-42889 | High | `commons-text` 1.9 | Text4Shell |

### First-party (SAST) — `vulnapp/`

| Category | Location | Notes |
|----------|----------|-------|
| OS command injection | `UnsafeOperations.java` — `runUserCommand` | User input concatenated into `Runtime.exec` shell command |
| Path traversal / arbitrary file read | `UnsafeOperations.java` — `readUserFile` | User-controlled path passed to `Files.readAllBytes` |
| SSRF | `UnsafeOperations.java` — `fetchUserUrl` | User-controlled URL opened via `URL.openStream` |
| SQL injection | `SqlHelper.java` — `buildUserLookupQuery` | Dynamic SQL built with string concatenation |
| Weak cryptography (MD5) | `InsecureCrypto.java` — `hashPasswordMd5` | MD5 used for password hashing |
| Unsafe Java deserialization | `UnsafeDeserialization.java` — `deserializeUntrusted` | `ObjectInputStream.readObject` on untrusted bytes |
| Hardcoded secrets in source | `HardcodedSecrets.java` | API key and database password constants; JDBC string with embedded password |
| Entry-point usage | `App.java` | Invokes unsafe helpers when CLI `mode` arguments are provided |

### Secrets — repository files

| Location | Notes |
|----------|-------|
| `fake-creds.txt` | Fake GitHub personal access token pattern (`gho_…`) for secret scanning |
| `HardcodedSecrets.java` | Hardcoded API key and password in application source (see first-party table) |

### Infrastructure as code — `iac/module.tf`

| Category | Location | Notes |
|----------|----------|-------|
| GKE basic auth enabled | `google_container_cluster.primary` — `master_auth` | Username/password authentication on control plane |
| Private endpoint disabled | `private_cluster_config` | `enable_private_endpoint = false` while nodes are private |
| Overly broad authorized network | `master_authorized_networks_config` | `192.168.20.0/24` with comment indicating wrong CIDR (`192.168.21.0/24` intended) |
| Legacy ABAC | `enable_legacy_abac` | Legacy attribute-based access control (variable-driven) |

## Layout

```
pom.xml              # Vulnerable dependency versions
vulnapp/             # First-party Java sources (SAST targets)
fake-creds.txt       # Secret-detection sample
iac/module.tf        # Terraform IaC sample
```
