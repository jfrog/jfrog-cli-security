package com.example.vulnapp;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Intentionally weak cryptography for first-party SAST scanning tests.
 */
public final class InsecureCrypto {

    private InsecureCrypto() {
    }

    /** Uses MD5 for password hashing (broken for this purpose). */
    public static byte[] hashPasswordMd5(String password) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("MD5");
        return digest.digest(password.getBytes());
    }
}
