package com.example.vulnapp;

/**
 * SQL injection via string concatenation for first-party SAST scanning tests.
 */
public final class SqlHelper {

    private SqlHelper() {
    }

    public static String buildUserLookupQuery(String username) {
        return "SELECT id, name FROM users WHERE username = '" + username + "'";
    }
}
